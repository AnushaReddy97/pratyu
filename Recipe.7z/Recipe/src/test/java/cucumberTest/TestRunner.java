package cucumberTest;
import org.junit.runner.RunWith;
import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;

@RunWith(Cucumber.class)
@CucumberOptions(
		features="features",
		glue="stepdefinitions",
		plugin= {"html:target/Destination"})
		// tags = "@causeeffect" )
	
	
public class TestRunner
{
	

}
