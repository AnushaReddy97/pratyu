package Integration;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
public class TestCase {
	WebDriver driver;
    	public TestCase(WebDriver driver) 
    		{
    			this.driver = driver;
    			  PageFactory.initElements(driver,this);
    		}
    	
    	@FindBy(xpath="/html/body/form/table/tbody/tr[12]/td/a")
        @CacheLookup
        WebElement download;
    	
    	@FindBy(id="fname")
        @CacheLookup
        WebElement firstname;
    	
    	@FindBy(id="lname")
        @CacheLookup
        WebElement lastname; 
    	
    	@FindBy(id="emails")
        @CacheLookup
        WebElement email;
    	
    	@FindBy(id="mobile")
        @CacheLookup
        WebElement mobilenumber;
       
    	@FindBy(name="D6")
        @CacheLookup
        WebElement categoryrecipe;
    	
    	@FindBy(name="D5")
        @CacheLookup
        WebElement city;
    	
    	@FindBy(name="D4")
        @CacheLookup
        WebElement learning;
    	
    	@FindBy(name="D3")
        @CacheLookup
        WebElement courseduration;
    	
    	@FindBy(id="enqdetails")
        @CacheLookup
        WebElement yourenquiry;
        
    	@FindBy(id="Submit1")
        @CacheLookup
        WebElement enter;
    	
    	@FindBy(xpath="/html/body/h3")
        @CacheLookup
        WebElement msg;
    	
    	public WebElement Download()
        {
            return download;
        }
       	
          
       public WebElement firstName()
        {
            return firstname;
        }
       	
       public WebElement lastName() 
       {
           return lastname;
       }

       public WebElement Emaild()
       {
           return email;
       }
       
       public WebElement Mobileno()
       {
           return mobilenumber;
       }
             
       public WebElement Category()
       {
           return categoryrecipe;
       }
       
       public WebElement City()
       {
           return city;
       }
       
       public WebElement Learning()
       {
           return learning;
       }
       
       public WebElement Course()
       {
           return courseduration;
       }
       
       public WebElement Enquiry()
       {
           return yourenquiry;
       }
       
       public WebElement enquireNow() 
       {
           return enter;
       }
       public WebElement message() 
       {
           return msg;
       }
          
}

	

