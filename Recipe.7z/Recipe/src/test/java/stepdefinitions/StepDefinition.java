package stepdefinitions;
import java.util.concurrent.TimeUnit;

import org.junit.Assert;
import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

import Integration.TestCase;
import cucumber.api.java.After;
import cucumber.api.java.Before;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
public class StepDefinition 
{
	WebDriver driver;
	TestCase obj;

@Given("^Clear the already created users before starting the scenario$")
public void Clear_the_already_created_users_before_starting_the_scenario() throws Throwable 
{
	 System.out.println("asdf");
	 System.setProperty("webdriver.chrome.driver", "./drivers/chromedriver.exe");
     driver=new ChromeDriver();
     driver.manage().window().maximize();
     driver.manage().timeouts().implicitlyWait(30,TimeUnit.SECONDS);
     obj= new TestCase(driver);
     
 }

@Given("^User entered the registration page by using URL$")
public void User_entered_the_registration_page_by_using_url() throws Throwable 
{
	driver.get("file:///C:/examweb/Recipe_class_registration.html");
}

@When("^user clicks on the hyperlink download our recipe class brochure$")
public void user_clicks_on_the_hyperlink_download_our_recipe_class_brochure() throws Throwable 
{
	 System.out.println("asdf");
	 obj.Download().click();
	 Thread.sleep(2000);
}

@When("^user filled all the fields$")
public void user_filled_all_the_fields() throws Throwable 
{
	System.out.println("asdf");
	obj.firstName().sendKeys("Pratyusha");
	obj.lastName().sendKeys("Kuchipudi");
	obj.Emaild().sendKeys("kuchipudi.sripratyusha@gmail.com");
	obj.Mobileno().sendKeys("7075134031");
	Select val= new Select (obj.Category());
    val.selectByVisibleText("Veg");

	/*obj.Category().click();
    obj.Category().sendKeys(Keys.ARROW_DOWN);
	obj.Category().sendKeys(Keys.ARROW_DOWN);
	obj.Category().sendKeys(Keys.ENTER);*/
	obj.City().click();
	obj.City().sendKeys(Keys.ARROW_DOWN);
    obj.City().sendKeys(Keys.ARROW_DOWN);
	obj.City().sendKeys(Keys.ENTER);
	obj.Learning().click();
	obj.Learning().sendKeys(Keys.ARROW_DOWN);
	obj.Learning().sendKeys(Keys.ARROW_DOWN);
	obj.Learning().sendKeys(Keys.ENTER);
	obj.Course().click();
	obj.Course().sendKeys(Keys.ARROW_DOWN);
	obj.Course().sendKeys(Keys.ARROW_DOWN);
	obj.Course().sendKeys(Keys.ARROW_DOWN);
	obj.Course().sendKeys(Keys.ENTER);
	obj.Enquiry().sendKeys("Nothing");
}


@When("^user left the first name field empty$")
public void user_left_the_first_name_field_empty() throws Throwable {
	System.out.println("asdf");
	obj.firstName().sendKeys("");
	
}

@When("^user left the mobile field field empty$")
public void user_left_the_mobile_field_field_empty() throws Throwable {
	 obj.Mobileno().sendKeys("");
}

@When("^user enters the data other than numeric values in mobile field$")
public void user_enters_the_data_other_than_numeric_values_in_mobile_field() throws Throwable {
	 System.out.println("asdf");
	 obj.Mobileno().sendKeys("dgstreh#");
}

@When("^user enters the numeric data more or less than ten digits$")
public void user_enters_the_numeric_data_more_or_less_than_ten_digits() throws Throwable {
	 System.out.println("asdf");
	 obj.Mobileno().sendKeys("436356");
}

@Then("^recipe class brochure is sent to your registered email id$")
public void recipe_class_brochure_is_sent_to_your_registered_email_id() throws Throwable {
	 System.out.println("asdf");
	 
}

@Then("^a message is displayed that thankyou for submitting the online recipe class enquiry$")
public void a_message_is_displayed_that_thankyou_for_submitting_the_online_recipe_class_enquiry() throws Throwable {
	 Alert alert = driver.switchTo().alert();
	 String expected = "Thank you for submitting the online recipe class Enquiry";
     String actual =alert.getText();
      Assert.assertEquals(expected, actual);   
      alert.accept();
}

@Then("^an alert box is displayed that first name should be filled out$")
public void an_alert_box_is_displayed_that_first_name_should_be_filled_out() throws Throwable {
	
	 Alert alert = driver.switchTo().alert();
     String expected = "First Name must be filled out";
     String actual =alert.getText();
      Assert.assertEquals(expected, actual);   
      alert.accept();
}

@Then("^an alert box is displayed that mobile field should be filled out$")
public void an_alert_box_is_displayed_that_mobile_field_should_be_filled_out() throws Throwable {
	Alert alert = driver.switchTo().alert();
    String expected = "Mobile must be filled out";
    String actual =alert.getText();
     Assert.assertEquals(expected, actual);   
     alert.accept();
}

@Then("^an alert box is displayed that enter numeric value$")
public void an_alert_box_is_displayed_that_enter_numeric_value() throws Throwable
{
	Alert alert = driver.switchTo().alert();
    String expected = "Enter numeric value";
    String actual =alert.getText();
     Assert.assertEquals(expected, actual);   
     alert.accept();
	
}

@Then("^an alert box is displayed that enter ten digit mobile number$")
public void an_alert_box_is_displayed_that_enter_ten_digit_mobile_number() throws Throwable
{
	Alert alert = driver.switchTo().alert();
    String expected = "Enter 10 digit Mobile number";
    String actual =alert.getText();
     Assert.assertEquals(expected, actual);   
     alert.accept();
	
}

@And("^Clicks on the enquire now button$")
public void Clicks_on_the_enquire_nowbutton() throws Throwable {
	
	 obj.enquireNow().click();
	 
}

@And("^a text is displayed as our location representative will contact you soon$")
public void a_text_is_displayed_as_our_location_representative_will_contact_you_soon() throws Throwable {
	 String expected = "Our location representative will contact you soon.";
     String actual =obj.message().getText();
      Assert.assertEquals(expected, actual);
}
@After
public void after()
{
    driver.quit();
}

}

