package pack1;
import pack1.Home;




import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;
import org.junit.Assert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

 

 
public class LoginApplication 
{    
    WebDriver driver;
    @BeforeMethod
    public void before()
    {    
        System.setProperty("webdriver.chrome.driver", "C:\\drivers/chromedriver.exe");
        driver=new ChromeDriver();
        System.out.println("Start");
    }
    @Test
    public void Login() throws InterruptedException
    {
        driver.manage().window().maximize();
        driver.get("https://demo.opencart.com");
       Home raid=new Home(driver);
        raid.Account().click();
        raid.Login().click();
        raid.Emaild().sendKeys("nikita2@gmail.com");
        raid.Password().sendKeys("nikita");
        raid.log().click();
        String expected = "My Account";
        String actual = driver.getTitle();
        Assert.assertEquals(expected,actual);
        System.out.println(actual);
            
    }
                
    @AfterMethod
    public void after()
    {
        System.out.println("Stop");
        driver.close();
    }
}
