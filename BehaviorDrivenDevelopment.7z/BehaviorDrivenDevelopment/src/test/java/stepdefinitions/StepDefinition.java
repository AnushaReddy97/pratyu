package stepdefinitions;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import Integration.Implementation;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
public class StepDefinition 
{
	 WebDriver driver;
	 Implementation obj;
	 @Given("^User entered the login page by using URL$")
	    public void user_entered_the_login_page_by_using_url() throws Throwable 
	 {
		 System.out.println("Pratyusha");
	 }

	    @Given("^User is on login page$")
	    public void user_is_on_login_page() throws Throwable {
	    	System.out.println("hhhh");
	    }

	    @When("^user left the email field empty$")
	    public void user_left_the_email_field_empty() throws Throwable {
	    	System.out.println("hhhh");
	    }

	    @When("^user left the password field empty$")
	    public void user_left_the_password_field_empty() throws Throwable {
	    	System.out.println("hhhh");
	    }

	    @When("^user left the email and password field empty$")
	    public void user_left_the_email_and_password_field_empty() throws Throwable {
	    	System.out.println("hhhh");
	    }

	    @When("^user gives correct email and password empty$")
	    public void user_gives_correct_email_and_password_empty() throws Throwable {
	    	System.out.println("hhhh");
	    }

	    @Then("^Error message is displayed that email field should not be left empty$")
	    public void error_message_is_displayed_that_email_field_should_not_be_left_empty() throws Throwable {
	    	System.out.println("hhhh");
	    }

	    @Then("^Error message is displayed that passsword field should not be left empty$")
	    public void error_message_is_displayed_that_passsword_field_should_not_be_left_empty() throws Throwable {
	    	System.out.println("hhhh");
	    }

	    @Then("^Error message is displayed that email and passsword field should not be left empty$")
	    public void error_message_is_displayed_that_email_and_passsword_field_should_not_be_left_empty() throws Throwable {
	    	System.out.println("hhhh");
	    }

	    @Then("^Successful login$")
	    public void successful_login() throws Throwable {
	    	System.out.println("hhhh");
	    }

	    @And("^Clicks on login button$")
	    public void clicks_on_login_button() throws Throwable 
	    {
	    	System.out.println("hhhh");
	    }
	    @When("^we enter email (.+) and password (.+) data$")
	    public void we_enter_email_and_password_data(String user, String pass) throws Throwable
	    {
	    	System.out.println("hhhh");
	    }

	    @Then("^I got second expected result$")
	    public void i_got_second_expected_result() throws Throwable {
	    	System.out.println("hhhh");
	    }
	    @Given("^Clear the already created users before starting the scenario$")
	    public void clear_the_already_created_users_before_starting_the_scenario() throws Throwable
	    {
	        System.out.println("Background");
	        System.setProperty("webdriver.chrome.driver", "./drivers/chromedriver.exe");
	        driver=new ChromeDriver();
	        driver.get("https://demo.opencart.com");
	        obj=new Implementation(driver);
	        obj.Account().click();
	        obj.Login().click();
	        
	        
	    }

	
	
}
