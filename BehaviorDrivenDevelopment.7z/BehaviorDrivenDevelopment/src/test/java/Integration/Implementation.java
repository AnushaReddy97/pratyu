package Integration;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
public class Implementation
{
       WebDriver driver;
        public Implementation(WebDriver driver) 
        {
            this.driver=driver;
            PageFactory.initElements(driver, this);
        }
        //Using PageFactory
        @FindBy(linkText="My Account")
        @CacheLookup
        WebElement account;  
       
        @FindBy(linkText="Login")
        @CacheLookup
        WebElement enter;    
        @FindBy(name="email")
        @CacheLookup
        WebElement user;
        @FindBy(name="password")
        @CacheLookup
        WebElement pass;
        @FindBy(xpath="//input[@value='Login']")
        @CacheLookup
        WebElement log;
          
       
        public WebElement Account() 
        {
            return account;
        }

       public WebElement Login() 
        {
            return enter;
        }
            
       public WebElement Emaild()
       {
           return user;
       }
             
       public WebElement Password()
       {
           return pass;
       }
       
       public WebElement log()
       {
           return log;
       
}

	 
	}

 
