package Integration;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
public class Implementation 
{
	WebDriver driver;
	public Implementation (WebDriver driver) 
		{
			this.driver = driver;
			  PageFactory.initElements(driver,this);
		}
	
	/*@FindBy(xpath="//*[@id=\"mainCnt\"]/div/div/h3")
    @CacheLookup
    WebElement papersub;
	
	@FindBy(xpath="//*[@id=\"mainCnt\"]/div/div/form/h3/a")
    @CacheLookup
    WebElement subcatbut;
	
	@FindBy(xpath="/html/body/h3")
    @CacheLookup
    WebElement subcat;
	
	@FindBy(xpath="/html/body/p/a")
    @CacheLookup
    WebElement backbut;
	
	
	@FindBy(xpath="//*[@id=\"mainCnt\"]/div/div/form/table/tbody/tr[1]/th")
    @CacheLookup
    WebElement loginform;
	
	@FindBy(name="userName")
    @CacheLookup
    WebElement uname;
	
	@FindBy(name="userPwd")
    @CacheLookup
    WebElement pass;
	
	@FindBy(xpath="//*[@id=\"mainCnt\"]/div/div/form/table/tbody/tr[4]/td[2]/input")
    @CacheLookup
    WebElement loginbut;
    */
	 
	@FindBy(xpath="/html/body/div/h2")
    @CacheLookup
    WebElement tt;
	
	@FindBy(id="txtFullName")
    @CacheLookup
    WebElement fname;
	
	@FindBy(xpath="//*[@id=\"txtEmail\"]")
    @CacheLookup
    WebElement email;
	
	@FindBy(xpath="//*[@id=\"txtPhone\"]")
    @CacheLookup
    WebElement mobile;
	
	@FindBy(name="city")
    @CacheLookup
    WebElement city;
	
	@FindBy(name="state")
    @CacheLookup
    WebElement state;
	
	@FindBy(xpath="//*[@id=\"txtCardholderName\"]")
    @CacheLookup
    WebElement subject;
	
	@FindBy(name="debit")
    @CacheLookup
    WebElement paper;
	
	@FindBy(id="txtCvv")
    @CacheLookup
    WebElement authors;
	
	@FindBy(name="month")
    @CacheLookup
    WebElement company;
	
	@FindBy(name="year")
    @CacheLookup
    WebElement desig;
	
	@FindBy(xpath="//*[@id=\"btnPayment\"]")
    @CacheLookup
    WebElement confirm;
	
	@FindBy(xpath="//input[@value='male']")
    @CacheLookup
    WebElement gen;
	
	@FindBy(xpath="/html/body/h1")
    @CacheLookup
    WebElement com;
	
	
	
	
	/*public WebElement papertt()
    {
        return papersub;
    }
   	
	public WebElement subclick()
    {
        return subcatbut;
    }
      
	public WebElement subhead()
    {
        return subcat;
    }
	public WebElement back()
    {
        return backbut;
    }
	public WebElement logformdisp()
    {
        return loginform;
    }
   public WebElement userName()
    {
        return uname;
    }
   	
   public WebElement password() 
   {
       return pass;
   }
   public WebElement logbut()
   {
       return loginbut;
   }
   */
   
   public WebElement fullName()
   {
       return fname;
   }
  	
   public WebElement Emaild()
   {
       return email;
   }
   
   public WebElement Mobileno()
   {
       return mobile;
   }
   
   public WebElement City()
   {
       return city;
   }
   
   public WebElement State()
   {
       return state;
   }
   
   public WebElement subjects()
   {
       return subject;
   }
   
   public WebElement papers()
   {
       return paper;
   }
        
         
   public WebElement Author()
   {
       return authors;
   }
   public WebElement cmpname()
   {
       return company;
   }
   
   public WebElement role()
   {
       return desig;
   }
        
         
   public WebElement cfmbut()
   {
       return confirm;
   }
   public WebElement genderbut()
   {
       return gen;
   }
   public WebElement regtt()
   {
       return tt;
   }
   public WebElement regcom()
   {
       return com;
   }
   
}
