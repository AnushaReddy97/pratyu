package Integration;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class TestCase
{
	WebDriver driver;
	public TestCase (WebDriver driver) 
		{
			this.driver = driver;
			  PageFactory.initElements(driver,this);
		}
	@FindBy(xpath="//*[@id=\"mainCnt\"]/div/div/h3")
    @CacheLookup
    WebElement papersub;
	
	@FindBy(xpath="//*[@id=\"mainCnt\"]/div/div/form/h3/a")
    @CacheLookup
    WebElement subcatbut;
	
	@FindBy(xpath="/html/body/h3")
    @CacheLookup
    WebElement subcat;
	
	@FindBy(xpath="/html/body/p/a")
    @CacheLookup
    WebElement backbut;
	
	
	@FindBy(xpath="//*[@id=\"mainCnt\"]/div/div/form/table/tbody/tr[1]/th")
    @CacheLookup
    WebElement loginform;
	
	@FindBy(name="userName")
    @CacheLookup
    WebElement uname;
	
	@FindBy(name="userPwd")
    @CacheLookup
    WebElement pass;
	
	@FindBy(xpath="//*[@id=\"mainCnt\"]/div/div/form/table/tbody/tr[4]/td[2]/input")
    @CacheLookup
    WebElement loginbut;
	
	@FindBy(xpath="//*[@id=\"pwdErrMsg\"]")
    @CacheLookup
    WebElement err;
	
	@FindBy(xpath="//*[@id=\"userErrMsg\"]")
    @CacheLookup
    WebElement erru;
	
	public WebElement papertt()
    {
        return papersub;
    }
   	
	public WebElement subclick()
    {
        return subcatbut;
    }
      
	public WebElement subhead()
    {
        return subcat;
    }
	public WebElement back()
    {
        return backbut;
    }
	public WebElement logformdisp()
    {
        return loginform;
    }
   public WebElement userName()
    {
        return uname;
    }
   	
   public WebElement password() 
   {
       return pass;
   }
   public WebElement logbut()
   {
       return loginbut;
   }
   public WebElement errmsgp()
   {
       return err;
   }
   public WebElement error()
   {
       return erru;
   }
  
}
