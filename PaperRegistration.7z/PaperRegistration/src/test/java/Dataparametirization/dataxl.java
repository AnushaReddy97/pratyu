package Dataparametirization;

import java.io.FileInputStream;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

public class dataxl {
	WebDriver driver;
	 @BeforeMethod
	 public void test1() throws InterruptedException
	 {
	 System.setProperty("webdriver.chrome.driver","./drivers/chromedriver.exe");
	 driver=new ChromeDriver();
	 driver.get("file://ndafile/Study%20Materials/VnV/Module%204/VV%20AT%20M4_MPT%20Sample%20Que/registration.html");
	 }
	 @Test(dataProvider = "user")
	    public void verify(String fname,String email, String mobileno ) throws Exception
	    {
		 driver.findElement(By.id("txtFullName")).sendKeys(fname);
		 driver.findElement(By.name("Email")).sendKeys(email);
		 driver.findElement(By.name("Phone")).sendKeys(mobileno);
	    }
	 @DataProvider(name="user")
	    public String[][] data() throws Exception
	    {
	        String[][] arrobj = getDataFromXLSX("reg.xlsx");
	        return arrobj;            
	    }
	    public String[][] getDataFromXLSX(String filename) throws Exception
	    {
	        String[][] array = null;
	        
	        FileInputStream fs = new FileInputStream(filename);
	        XSSFWorkbook wb = new XSSFWorkbook(fs);
	        XSSFSheet sh = wb.getSheetAt(0);
	        XSSFRow rows;
	        XSSFCell cell;
	        
	        int rowCount = sh.getLastRowNum();
	        int columnCount = sh.getRow(0).getLastCellNum();
	        
	        array = new String[rowCount][columnCount];
	        for(int i=1; i<rowCount+1;i++)
	        {
	            for(int j=0; j<columnCount;j++)
	            {
	                rows = sh.getRow(i);
	                cell = rows.getCell(j);
	                array[i-1][j] = cell.getStringCellValue();
	            }
	        }
	        return array;
	    }
	 
	 
	  @AfterMethod
	    public void after()
	    {
	    	driver.quit();
	    }
}



