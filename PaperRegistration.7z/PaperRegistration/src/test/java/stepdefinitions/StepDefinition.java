package stepdefinitions;
import java.util.concurrent.TimeUnit;
import org.junit.Assert;
import org.openqa.selenium.Alert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;
import Integration.Implementation;
import Integration.TestCase;
import cucumber.api.java.After;
import cucumber.api.java.Before;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class StepDefinition
{
	
	WebDriver driver;
	Implementation ip;
	TestCase tc;
	@Before
    public void before()
    {
        System.setProperty("webdriver.chrome.driver","./drivers/chromedriver.exe");
        driver = new ChromeDriver();
        driver.manage().window().maximize();
        driver.manage().timeouts().implicitlyWait(3000,TimeUnit.SECONDS);
        ip = new Implementation(driver);
        tc = new TestCase(driver);
    }
	
	 @Given("^User has valid URL$")
	    public void user_has_valid_url() throws Throwable 
	 {
		 driver.get("file://ndafile/Study%20Materials/VnV/Module%204/VV%20AT%20M4_MPT%20Sample%20Que/login.html"); 
	  }

	    @Given("^User entered the login form by using URL$")
	    public void user_entered_the_login_form_by_using_url() throws Throwable 
	    {
	       
	    }

	    @Given("^User entered Registration page the by using URL$")
	    public void User_entered_registration_page_the_by_using_url() throws Throwable {
	    	 driver.get("file://ndafile/Study%20Materials/VnV/Module%204/VV%20AT%20M4_MPT%20Sample%20Que/registration.html"); 
	    	 Thread.sleep(3000);
	    }


	    @When("^user clicks on the Click here to know the Subject Categories$")
	    public void user_clicks_on_the_click_here_to_know_the_subject_categories() throws Throwable 
	    {
	    	tc.subclick().click();
	    }

	    @When("^user gives the correct username and password$")
	    public void user_gives_the_correct_username_and_password() throws Throwable {
	    	tc.userName().sendKeys("vrl"); 
	    	tc.password().sendKeys("vrl1234");  
	    }

	    @When("^user left the username field empty$")
	    public void user_left_the_username_field_empty() throws Throwable {
	    	tc.userName().sendKeys("");
	       
	    }
	    @When("^user left the password field empty$")
	    public void user_left_the_password_field_empty() throws Throwable {
	    	tc.userName().sendKeys("vrl"); 
	    	tc.password().sendKeys("");
	    }


	    @When("^user left the full name field empty$")
	    public void user_left_the_full_name_field_empty() throws Throwable 
	    {
	    	ip.fullName().sendKeys("");
	         }

	    @When("^user fills the email in wrong format$")
	    public void user_fills_the_email_in_wrong_format() throws Throwable {
	    	ip.fullName().sendKeys("hfdj");
	    	 ip.Emaild().sendKeys("kuch76453");
	    }


	    @When("^user left the mobile field empty$")
	    public void user_left_the_mobile_field_empty() throws Throwable {
	    	ip.fullName().sendKeys("hfdj");
	    	 ip.Emaild().sendKeys("kuch@gmail.com");
	    	ip.Mobileno().sendKeys("");
	    }

	    @When("^user enters the numeric data more or less than ten digits or does not start with 7,8,9$")
	    public void user_enters_the_numeric_data_more_or_less_than_ten_digits_or_does_not_start_with_789() throws Throwable {
	    	ip.fullName().sendKeys("hfdj");
	    	 ip.Emaild().sendKeys("kuch@gmail.com");
	    	ip.Mobileno().sendKeys("21653");
	    }

	    @When("^user left the City field empty$")
	    public void user_left_the_city_field_empty() throws Throwable {
	    	ip.fullName().sendKeys("hfdj");
	    	 ip.Emaild().sendKeys("kuch@gmail.com");
	    	 ip.Mobileno().sendKeys("7075134031");
	    	ip.City().sendKeys("");
	    }
	    @When("^user left the state field empty$")
	    public void user_left_the_state_field_empty() throws Throwable {
	    	ip.fullName().sendKeys("hfdj");
	    	 ip.Emaild().sendKeys("kuch@gmail.com");
	    	 ip.Mobileno().sendKeys("7075134031");
	    	 ip.City().sendKeys("Pune");
	    	ip.State().sendKeys("");
	    }


	    @When("^user left the subject category field empty$")                                                                                                                                                                                                                                                                                                                                                                                                                                                                     
	    public void user_left_the_subject_category_field_empty() throws Throwable {
	    	ip.fullName().sendKeys("hfdj");
	    	 ip.Emaild().sendKeys("kuch@gmail.com");
	    	 ip.Mobileno().sendKeys("7075134031");
	    	 ip.City().sendKeys("Pune");
	    	ip.State().sendKeys("Telangana");
	    	ip.subjects().sendKeys("");
	    }

	    @When("^user left the paper name field empty$")                                                                                                                                                                                                                                                                                                                                                                                                                                                                     
	    public void user_left_the_paper_name_field_empty() throws Throwable {
	    	ip.fullName().sendKeys("hfdj");
	    	 ip.Emaild().sendKeys("kuch@gmail.com");
	    	 ip.Mobileno().sendKeys("7075134031");
	    	 ip.City().sendKeys("Pune");
	    	ip.State().sendKeys("Telangana");
	    	ip.subjects().sendKeys("fehyt");
	    	ip.papers().sendKeys("");
	    }

	    @When("^user left the authors field empty$")                                                                                                                                                                                                                                                                                                                                                                                                                                                                      
	    public void user_left_the_authors_field_empty() throws Throwable {
	    	ip.fullName().sendKeys("hfdj");
	    	 ip.Emaild().sendKeys("kuch@gmail.com");
	    	 ip.Mobileno().sendKeys("7075134031");
	    	 ip.City().sendKeys("Pune");
	    	ip.State().sendKeys("Telangana");
	    	ip.subjects().sendKeys("fehyt");
	    	ip.papers().sendKeys("ytru");
	    	ip.Author().sendKeys("");
	    }

	    @When("^user left the company name field empty$")                                                                                                                                                                                                                                                                                                                                                                                                                                                                      
	    public void user_left_the_company_name_field_empty() throws Throwable {
	    	ip.fullName().sendKeys("hfdj");
	    	 ip.Emaild().sendKeys("kuch@gmail.com");
	    	 ip.Mobileno().sendKeys("7075134031");
	    	 ip.City().sendKeys("Pune");
	    	ip.State().sendKeys("Telangana");
	    	ip.subjects().sendKeys("fehyt");
	    	ip.papers().sendKeys("ytru");
	    	ip.Author().sendKeys("1");
	    	ip.cmpname().sendKeys("");
	    }

	    @When("^user left the designation field empty$")
	    public void user_left_the_designation_field_empty() throws Throwable {
	    	ip.fullName().sendKeys("hfdj");
	    	 ip.Emaild().sendKeys("kuch@gmail.com");
	    	 ip.Mobileno().sendKeys("7075134031");
	    	 ip.City().sendKeys("Pune");
	    	ip.State().sendKeys("Telangana");
	    	ip.subjects().sendKeys("fehyt");
	    	ip.papers().sendKeys("ytru");
	    	ip.Author().sendKeys("1");
	    	ip.cmpname().sendKeys("cdtr");
	    	ip.role().sendKeys("");
	    }


	   

	    @Then("^user navigates to the topics page having subject categories$")
	    public void user_navigates_to_the_topics_page_having_subject_categories() throws Throwable {
	       
	    }

	    @Then("^the user navigates to the Registration page$")
	    public void the_user_navigates_to_the_registration_page() throws Throwable {
	       
	    }

	    @Then("^a message is displayed as registration completed$")
	    public void a_message_is_displayed_as_registration_completed() throws Throwable {
	    	String expected ="Registration Completed!";
	    	String act = ip.regcom().getText();
	         System.out.println(act);
	         Assert.assertEquals(expected, act);
	         Thread.sleep(3000);
	    }

	    @Then("^a message is displayed as please enter UserName$")
	    public void a_message_is_displayed_as_please_enter_username() throws Throwable {
	    	String expected = "* Please enter userName.";
	    	String act = tc.error().getText();
	         System.out.println(act);
	         Assert.assertEquals(expected, act);
	         
	    }

	    @Then("^a message is displayed as please enter password$")
	    public void a_message_is_displayed_as_please_enter_password() throws Throwable {
	    	String expected ="* Please enter password.";
	    	String act = tc.errmsgp().getText();
	         System.out.println(act);
	         Assert.assertEquals(expected, act);
	         Thread.sleep(3000);
	    }

	    @Then("^an alert box is displayed as Please fill the Full Name$")
	    public void an_alert_box_is_displayed_as_please_fill_the_full_name() throws Throwable {
	    	Alert alert = driver.switchTo().alert();
	   	    String expected = "Please fill the Full Name";
	        String actual =alert.getText();
	         Assert.assertEquals(expected, actual);   
	         Thread.sleep(2000);
	         alert.accept();
	         
	   }
	    

	    @Then("^an alert box is displayed as Please fill the Email$")
	    public void an_alert_box_is_displayed_as_please_fill_the_email() throws Throwable {
	    Alert alert = driver.switchTo().alert();
	   	    String expected = "Please enter valid Email Id.";
	        String actual =alert.getText();
	        System.out.println(actual);
	        Assert.assertEquals(expected, actual); 
	         Thread.sleep(2000);
	         alert.accept();
	    }

	    @Then("^an alert box is displayed as Please fill the mobile no$")
	    public void an_alert_box_is_displayed_as_please_fill_the_mobile_no() throws Throwable {
	    	Alert alert = driver.switchTo().alert();
	   	    String expected = "Please fill the Mobile No.";
	        String actual =alert.getText();
	         Assert.assertEquals(expected, actual);  
	         Thread.sleep(2000);
	         alert.accept();
	    }

	    @Then("^an alert box is displayed that Please enter valid Contact no$")
	    public void an_alert_box_is_displayed_that_please_enter_valid_contact_no() throws Throwable {
	    	Alert alert = driver.switchTo().alert();
	   	    String expected = "Please enter valid Contact no.";
	        String actual =alert.getText();
	         Assert.assertEquals(expected, actual);  
	         Thread.sleep(2000);
	         alert.accept();
	    }

	    @Then("^an alert box is displayed as Please select city$")
	    public void an_alert_box_is_displayed_as_please_select_city() throws Throwable
	    {
	    	Alert alert = driver.switchTo().alert();
	   	    String expected = "Please select city";
	        String actual =alert.getText();
	         Assert.assertEquals(expected, actual); 
	         Thread.sleep(2000);
	         alert.accept();
	    }
	    

	    @Then("^an alert box is displayed as Please select state$")
	    public void an_alert_box_is_displayed_as_please_select_state() throws Throwable {
	    	Alert alert = driver.switchTo().alert();
	   	    String expected = "Please select state";
	        String actual =alert.getText();
	         Assert.assertEquals(expected, actual);  
	         Thread.sleep(2000);
	         alert.accept();
	    }

	    @Then("^an alert box is displayed as Please fill the subject category$")
	    public void an_alert_box_is_displayed_as_please_fill_the_subject_category() throws Throwable {
	    	Alert alert = driver.switchTo().alert();
	   	    String expected = "Please fill the Subject Category";
	        String actual =alert.getText();
	         Assert.assertEquals(expected, actual);   
	         alert.accept();
	    }

	    @Then("^an alert box is displayed as Please fill the paper name$")
	    public void an_alert_box_is_displayed_as_please_fill_the_paper_name() throws Throwable {
	    	Alert alert = driver.switchTo().alert();
	   	    String expected = "Please fill the Paper Name";
	        String actual =alert.getText();
	         Assert.assertEquals(expected, actual);   
	         alert.accept();
	    }

	    @Then("^an alert box is displayed as Please fill the authors$")
	    public void an_alert_box_is_displayed_as_please_fill_the_authors() throws Throwable {
	    	Alert alert = driver.switchTo().alert();
	   	    String expected = "Pls. fill the authors";
	        String actual =alert.getText();
	         Assert.assertEquals(expected, actual);   
	         alert.accept();
	    }

	    @Then("^an alert box is displayed as Please fill the expiration month$")
	    public void an_alert_box_is_displayed_as_please_fill_the_expiration_month() throws Throwable {
	    	Alert alert = driver.switchTo().alert();
	   	    String expected = "Please fill Company Name";
	        String actual =alert.getText();
	         Assert.assertEquals(expected, actual);   
	         alert.accept();
	    }

	    @Then("^an alert box is displayed as Please fill the expiration year$")
	    public void an_alert_box_is_displayed_as_please_fill_the_expiration_year() throws Throwable {
	    	Alert alert = driver.switchTo().alert();
	   	    String expected = "Please fill Designation";
	        String actual =alert.getText();
	         Assert.assertEquals(expected, actual);   
	         alert.accept();
	    }

	    @And("^user is able to see the heading as Paper submission for International Journal$")
	    public void user_is_able_to_see_the_heading_as_paper_submission_for_international_journal() throws Throwable {
	    	String expected ="Paper Submission for International Journal";
	    	String act = tc.papertt().getText();
	         System.out.println(act);
	         Assert.assertEquals(expected, act);
	         Thread.sleep(3000);
	    }

	    @And("^user clicks the back button$")
	    public void user_clicks_the_back_button() throws Throwable
	    {
	       tc.back().click();
	       Thread.sleep(3000);
	    }

	    @And("^user entered the login form$")
	    public void user_entered_the_login_form() throws Throwable {
	      
	    }

	    @And("^clicks on the login button$")
	    public void clicks_on_the_login_button() throws Throwable 
	    {
	    	tc.logbut().click();
	    }

	    @And("^user is able to see the heading as Paper Submissions for Capgemini International Research Journal$")
	    public void user_is_able_to_see_the_heading_as_paper_submissions_for_capgemini_international_research_journal() throws Throwable {
	    	String expected ="Paper Submissions for \"Capgemini International Research Journal\"";
	    	String actual = ip.regtt().getText();
	         System.out.println(actual);
	         Assert.assertEquals(expected, actual);
	         Thread.sleep(3000);
	    }

	    @And("^user enters the valid details$")
	    public void user_enters_the_valid_details() throws Throwable {
	    	ip.fullName().sendKeys("Pratyusha");
	        ip.Emaild().sendKeys("kuchipudi.sripratyusha@gmail.com");
	    	ip.Mobileno().sendKeys("7075134031");
	    	ip.genderbut().click();
	    	Select val= new Select (ip.City());
	        val.selectByVisibleText("Pune");
	        Select val1= new Select (ip.State());
	        val1.selectByVisibleText("Tamilnadu");
	        ip.subjects().sendKeys("Artificial Intelligence");
	        ip.papers().sendKeys("hi");
	        ip.Author().sendKeys("1");
	        ip.cmpname().sendKeys("hcl");
	        ip.role().sendKeys("Analyst");
	        
	        }
	    
	    @And("^user navigates to the success page$")
	    public void user_navigates_to_the_success_page() throws Throwable {
	        
	    }

	    @And("^Clicks on the Confirm Registration button$")
	    public void Clicks_on_the_confirm_registration_button() throws Throwable 
	    {
	    	ip.cfmbut().click();
	      
	    }
@After
	 public void after()
	   {
	        driver.quit();
	   }
	    
}
