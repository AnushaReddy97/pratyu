package Seleniumgrid;

import java.net.MalformedURLException;
import java.net.URL;

import org.openqa.selenium.Platform;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;

public class grid 
{

	public static void main(String[] args) throws MalformedURLException 
	{		System.setProperty("webdriver.chrome.driver","./drivers/chromedriver.exe");
			DesiredCapabilities dc=DesiredCapabilities.chrome();
			dc.setBrowserName("chrome");
			dc.setPlatform(Platform.WINDOWS);
			
			
			WebDriver driver=new RemoteWebDriver(new URL("http://10.219.34.226:5555/wd/hub"),dc);
			driver.get("file://ndafile/Study%20Materials/VnV/Module%204/VV%20AT%20M4_MPT%20Sample%20Que/registration.html");
			driver.manage().window().maximize();
			System.out.println(driver.getTitle());
	}
}
  

