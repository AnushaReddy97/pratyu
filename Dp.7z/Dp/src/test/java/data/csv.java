package data;

import java.io.DataInputStream;
import java.io.FileInputStream;

import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;

public class csv {
	WebDriver driver;
	
	@BeforeMethod
	public void beforeOneData()  //launch the browser before test
	{
		System.setProperty("webdriver.chrome.driver", "./drivers/chromedriver.exe");
		driver = new ChromeDriver();
	}

	@Test(dataProvider="Data")
	public void verifyInvalidData(String fname,String email,String phonenum) throws Exception
	{
		driver.get("file:////C://prat");
		Thread.sleep(1500);
		driver.findElement(By.id("txtFullName")).sendKeys(fname);
		Thread.sleep(1000);
		driver.findElement(By.name("Email")).sendKeys(email);
		Thread.sleep(1000);
		driver.findElement(By.name("Phone")).sendKeys(phonenum);
		Thread.sleep(1000);
	}

	@DataProvider(name="Data")
	public Object[][] actualData() throws Exception
	{
		Object[][] arrObj = getDataFromCSV("datas.csv");  //csv file name pass
		return arrObj;
	}
	
	@SuppressWarnings({ "deprecation", "resource" })
		public String[][] getDataFromCSV(String fName) throws Exception {
		String thisLine; 
		FileInputStream fis = new FileInputStream(fName);
		DataInputStream myInput = new DataInputStream(fis);
		int i = 0;//line count of csv
		String[][] data = new String[0][];//csv data line count=0 initially
		while ((thisLine = myInput.readLine()) != null) {
	
			String strar[] = thisLine.split(",");//get contents of line as an array
			String[][] newdata = new String[i][strar.length];//create new array for data
			if(i>0)
			{
				newdata[i - 1] = strar;//add new line to the array
				System.arraycopy(data, 0, newdata, 0, i - 1);//copy previously read values to new array
				data = newdata;//set new array as csv data
			}
			i++;
		}
		return data;
	}

	@AfterMethod
	public void AfterOneData() throws InterruptedException
	{
		driver.quit();
	}

}
